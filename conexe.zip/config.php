<?php
/*
 * @Author: Slash Web Design
 */

$config = array(
	'host'				=>  "localhost",
	'username'			=>  "root",
	'password'			=>  "",
	'database'			=>  "conexe",
	'site_url'			=>	"http://localhost/conexe/",

	'site_name'			=>	"Conexe",
	'debug'				=>	true,
	'live'				=>	true,

	'meta_title'		=>	"Conexe",
	'meta_keywords'		=>	"Conexe",
	'meta_description'	=>	"Conexe"
);